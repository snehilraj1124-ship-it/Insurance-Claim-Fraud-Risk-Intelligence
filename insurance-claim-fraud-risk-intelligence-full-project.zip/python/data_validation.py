import pandas as pd

DATA_PATH = "data/claims_sample.csv"

def validate_claims(path=DATA_PATH):
    df = pd.read_csv(path)
    required = {"claim_id", "policy_id", "customer_id", "provider_id", "claim_amount", "claim_date"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    df["claim_date"] = pd.to_datetime(df["claim_date"], errors="coerce")
    df["claim_amount"] = pd.to_numeric(df["claim_amount"], errors="coerce")
    return {
        "rows": len(df),
        "missing_values": int(df.isna().sum().sum()),
        "duplicate_claim_ids": int(df["claim_id"].duplicated().sum()),
        "invalid_dates": int(df["claim_date"].isna().sum()),
        "invalid_amounts": int(df["claim_amount"].isna().sum()),
    }

if __name__ == "__main__":
    print(validate_claims())
