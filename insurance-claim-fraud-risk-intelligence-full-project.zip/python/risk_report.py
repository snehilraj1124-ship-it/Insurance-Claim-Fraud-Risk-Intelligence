from anomaly_detection import detect_anomalies

def generate_report():
    df = detect_anomalies()
    return {
        "total_claims": len(df),
        "total_claim_value": float(df["claim_amount"].sum()),
        "flagged_claims": int(df["anomaly_flag"].sum()),
        "high_value_claims": int(df["high_value_flag"].sum()),
        "high_frequency_claims": int(df["high_frequency_flag"].sum()),
    }

if __name__ == "__main__":
    print(generate_report())
