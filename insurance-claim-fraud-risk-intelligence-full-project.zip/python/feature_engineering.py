import pandas as pd

def build_features(path="data/claims_sample.csv"):
    df = pd.read_csv(path)
    df["claim_date"] = pd.to_datetime(df["claim_date"])
    df["claim_amount"] = pd.to_numeric(df["claim_amount"])
    mean_amount = df["claim_amount"].mean()
    df["amount_ratio"] = (df["claim_amount"] / mean_amount).round(2)
    df["high_value_flag"] = (df["claim_amount"] > df["claim_amount"].quantile(0.80)).astype(int)
    df["high_frequency_flag"] = (df["previous_claims"] >= 5).astype(int)
    df["review_flag"] = (df["claim_status"].str.lower() == "review").astype(int)
    return df

if __name__ == "__main__":
    print(build_features().head())
