from feature_engineering import build_features

def detect_anomalies():
    df = build_features()
    df["anomaly_score"] = (
        df["high_value_flag"] * 0.45
        + df["high_frequency_flag"] * 0.35
        + df["review_flag"] * 0.20
    )
    df["anomaly_flag"] = (df["anomaly_score"] >= 0.55).astype(int)
    return df.sort_values("anomaly_score", ascending=False)

if __name__ == "__main__":
    print(detect_anomalies()[["claim_id", "anomaly_score", "anomaly_flag"]])
