DATA_PATH = 'data/claims_sample.csv'
HIGH_VALUE_THRESHOLD = 50000
