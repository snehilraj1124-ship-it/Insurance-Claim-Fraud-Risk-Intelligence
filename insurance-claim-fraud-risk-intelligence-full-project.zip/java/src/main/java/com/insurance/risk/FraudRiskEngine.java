package com.insurance.risk;

public class FraudRiskEngine {
    public static RiskScore score(ClaimRecord claim) {
        double score = 0.0;

        if (claim.getClaimAmount() >= 50000) score += 0.45;
        else if (claim.getClaimAmount() >= 20000) score += 0.25;

        if (claim.getPreviousClaims() >= 7) score += 0.35;
        else if (claim.getPreviousClaims() >= 4) score += 0.20;

        if (claim.isReviewFlag()) score += 0.20;

        String category = score >= 0.70 ? "HIGH"
                : score >= 0.40 ? "MEDIUM"
                : "LOW";

        return new RiskScore(claim.getClaimId(), score, category);
    }

    public static void main(String[] args) {
        ClaimRecord sample = new ClaimRecord("CLM-DEMO", 72000, 7, true);
        System.out.println(score(sample));
    }
}
