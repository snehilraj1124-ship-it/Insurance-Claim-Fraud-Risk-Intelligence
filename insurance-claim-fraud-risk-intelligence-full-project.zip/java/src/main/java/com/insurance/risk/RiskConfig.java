package com.insurance.risk;
public final class RiskConfig {
    public static final double HIGH_AMOUNT = 50000.0;
    private RiskConfig() {}
}
