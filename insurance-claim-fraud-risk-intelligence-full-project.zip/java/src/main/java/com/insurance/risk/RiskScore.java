package com.insurance.risk;

public class RiskScore {
    private final String claimId;
    private final double score;
    private final String category;

    public RiskScore(String claimId, double score, String category) {
        this.claimId = claimId;
        this.score = score;
        this.category = category;
    }

    @Override
    public String toString() {
        return claimId + " | score=" + String.format("%.2f", score) + " | category=" + category;
    }
}
