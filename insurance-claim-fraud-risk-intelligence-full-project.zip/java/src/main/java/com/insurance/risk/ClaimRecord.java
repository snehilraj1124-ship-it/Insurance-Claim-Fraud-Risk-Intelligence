package com.insurance.risk;

public class ClaimRecord {
    private final String claimId;
    private final double claimAmount;
    private final int previousClaims;
    private final boolean reviewFlag;

    public ClaimRecord(String claimId, double claimAmount, int previousClaims, boolean reviewFlag) {
        this.claimId = claimId;
        this.claimAmount = claimAmount;
        this.previousClaims = previousClaims;
        this.reviewFlag = reviewFlag;
    }

    public String getClaimId() { return claimId; }
    public double getClaimAmount() { return claimAmount; }
    public int getPreviousClaims() { return previousClaims; }
    public boolean isReviewFlag() { return reviewFlag; }
}
