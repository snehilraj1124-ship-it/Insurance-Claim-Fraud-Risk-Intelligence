# Web Dashboard

Open index.html in a browser to view the sample investigation dashboard.
