const priorities = [
  ["CLM010", "₹91,000", 8, "Review"],
  ["CLM015", "₹87,500", 6, "Review"],
  ["CLM006", "₹72,000", 7, "Review"],
  ["CLM004", "₹65,000", 2, "Review"],
  ["CLM012", "₹54,000", 5, "Review"]
];

const tbody = document.getElementById("tableBody");
priorities.forEach(row => {
  const tr = document.createElement("tr");
  tr.innerHTML = `<td>${row[0]}</td><td>${row[1]}</td><td>${row[2]}</td><td>${row[3]}</td>`;
  tbody.appendChild(tr);
});
