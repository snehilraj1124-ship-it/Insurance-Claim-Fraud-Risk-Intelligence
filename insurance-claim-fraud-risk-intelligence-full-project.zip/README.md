# Insurance Claim Fraud & Risk Intelligence

## Overview

**Insurance Claim Fraud & Risk Intelligence** is an end-to-end enterprise analytics prototype for analyzing insurance claims, policyholder behavior, provider activity, and suspicious claim patterns.

The project combines **Python, Java, SQL, HTML, CSS, and JavaScript** to demonstrate a practical workflow for insurance fraud analytics and risk intelligence.

The system is designed around a transparent analytical pipeline:

**Raw Claims → Data Validation → Feature Engineering → Anomaly Detection → Risk Scoring → Investigation Dashboard → Reporting**

> This is a portfolio/educational prototype. It does not make real insurance eligibility, pricing, or claim-settlement decisions.

## Objectives

- Analyze insurance claim and policyholder behavior.
- Identify unusual claim amounts and claim frequency.
- Detect duplicate or highly similar claims.
- Profile providers and customers using risk indicators.
- Generate explainable risk scores.
- Support investigator-oriented filtering and review.
- Produce management KPIs and analytical summaries.
- Demonstrate integration between analytics, backend logic, SQL investigation, and web visualization.

## Technology Stack

| Layer | Technology |
|---|---|
| Analytics | Python, Pandas, NumPy |
| Risk Logic | Java |
| Database / Investigation | SQL |
| Frontend | HTML5, CSS3, JavaScript |
| Testing | Python unittest |
| Data | CSV |
| Documentation | Markdown |

## Core Analytics

### 1. Claim Amount Analysis
Claims are compared with historical and peer-group statistics to identify unusually high amounts.

### 2. Frequency Monitoring
Repeated claims from the same policyholder or provider are analyzed for abnormal frequency.

### 3. Duplicate Claim Detection
Claim identifiers, dates, policy IDs, providers, and amounts can be compared to identify potential duplicates.

### 4. Provider Risk Profiling
Provider-level metrics such as claim volume, average claim value, rejection rate, and anomaly count are summarized.

### 5. Behavioral Anomaly Detection
The Python pipeline creates analytical indicators for unusual activity, including high-value claims, repeated activity, unusual timing, and cross-region patterns.

### 6. Explainable Risk Scoring
The Java component combines multiple indicators into a transparent risk score. The score is intended for analytical prioritization rather than an automated final decision.

## Suggested Project Structure

```text
insurance-claim-fraud-risk-intelligence/
├── README.md
├── data/
│   └── claims_sample.csv
├── docs/
│   ├── methodology.md
│   └── data_dictionary.md
├── python/
│   ├── data_validation.py
│   ├── feature_engineering.py
│   ├── anomaly_detection.py
│   └── risk_report.py
├── java/
│   └── src/main/java/com/insurance/risk/
│       ├── ClaimRecord.java
│       ├── RiskScore.java
│       └── FraudRiskEngine.java
├── sql/
│   ├── schema.sql
│   ├── investigation_queries.sql
│   └── provider_risk.sql
├── web/
│   ├── index.html
│   ├── css/style.css
│   └── js/dashboard.js
└── tests/
    └── test_risk_pipeline.py
```

## Analytical Workflow

1. Load the claims dataset.
2. Validate required fields and data types.
3. Clean missing and inconsistent records.
4. Engineer claim-level and customer-level indicators.
5. Detect anomalous observations.
6. Calculate transparent risk factors.
7. Aggregate customer and provider metrics.
8. Query high-risk cases using SQL.
9. Apply Java risk-scoring logic.
10. Present KPIs and investigation views through the web dashboard.

## Risk Indicators

Example indicators used in the prototype include:

- High claim amount
- High claim frequency
- Repeated provider usage
- Duplicate claim pattern
- Unusual claim timing
- Abnormal provider activity
- Multiple claims within a short period
- Historical anomaly count

## Running the Python Analytics

Install the basic dependencies:

```bash
pip install pandas numpy
```

Run the validation and analysis scripts:

```bash
python python/data_validation.py
python python/feature_engineering.py
python python/anomaly_detection.py
python python/risk_report.py
```

## Running the Java Risk Engine

Compile the Java classes:

```bash
javac -d java/bin java/src/main/java/com/insurance/risk/*.java
```

Run the risk engine:

```bash
java -cp java/bin com.insurance.risk.FraudRiskEngine
```

## SQL Investigation

The SQL folder contains schema definitions and investigation queries for:

- high-value claims
- repeated claimants
- provider-level risk
- duplicate claims
- high-frequency activity
- risk-priority cases

## Dashboard

Open:

```text
web/index.html
```

The dashboard provides a lightweight interface for reviewing:

- total claims
- total claim value
- suspicious claim count
- high-risk cases
- provider risk indicators
- claim distribution
- investigation priorities

## Data Dictionary

The sample dataset contains fields such as:

| Field | Description |
|---|---|
| claim_id | Unique claim identifier |
| policy_id | Policy identifier |
| customer_id | Policyholder identifier |
| provider_id | Service/provider identifier |
| claim_amount | Amount requested in the claim |
| claim_date | Date of claim |
| claim_type | Category of claim |
| region | Claim region |
| previous_claims | Historical claim count |
| claim_status | Current claim status |

## Design Principles

- Explainability over black-box decisions.
- Modular separation of analytics, risk logic, SQL, and presentation.
- Reproducible sample-data workflow.
- Investigator-oriented outputs.
- No sensitive production insurance data is required.

## Future Enhancements

- PostgreSQL/MySQL integration
- REST API using Spring Boot
- Interactive Plotly dashboard
- Model comparison using Isolation Forest and supervised classifiers
- Feature-store architecture
- Role-based investigator access
- Model monitoring and drift detection
- Docker deployment
- CI/CD automation
- Synthetic data generation at scale

## Disclaimer

This repository is intended for **educational and portfolio purposes**. Fraud indicators and risk scores are analytical examples and should not be treated as proof of fraud or used as a substitute for human investigation, regulatory review, or organizational claim procedures.
