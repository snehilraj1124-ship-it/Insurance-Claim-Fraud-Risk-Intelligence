import unittest
from python.feature_engineering import build_features
from python.anomaly_detection import detect_anomalies

class TestRiskPipeline(unittest.TestCase):
    def test_feature_columns(self):
        df = build_features()
        self.assertIn("amount_ratio", df.columns)
        self.assertIn("high_value_flag", df.columns)

    def test_anomaly_score(self):
        df = detect_anomalies()
        self.assertIn("anomaly_score", df.columns)
        self.assertTrue((df["anomaly_score"] >= 0).all())

if __name__ == "__main__":
    unittest.main()
