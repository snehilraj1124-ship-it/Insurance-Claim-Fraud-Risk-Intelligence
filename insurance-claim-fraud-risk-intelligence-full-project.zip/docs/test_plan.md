# Test Plan

1. Validate required CSV columns.
2. Check invalid dates and amounts.
3. Verify engineered risk indicators.
4. Confirm anomaly scores are non-negative.
5. Verify Java score category boundaries.
6. Check dashboard rendering with sample records.
7. Validate SQL aggregation outputs against sample data.
