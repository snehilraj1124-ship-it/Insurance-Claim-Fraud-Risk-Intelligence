# Project Scope

## In Scope
- Synthetic/sample claim analysis
- Explainable risk indicators
- Customer and provider profiling
- SQL investigation workflows
- Dashboard presentation
- Java risk scoring demonstration

## Out of Scope
- Real customer data
- Automated claim rejection
- Definitive fraud determination
- Production underwriting or pricing decisions
