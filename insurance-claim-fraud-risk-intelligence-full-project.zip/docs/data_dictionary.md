# Data Dictionary

- `claim_id`: Unique claim identifier.
- `policy_id`: Insurance policy identifier.
- `customer_id`: Policyholder identifier.
- `provider_id`: Service/provider identifier.
- `claim_amount`: Monetary value requested by the claim.
- `claim_date`: Date the claim was submitted.
- `claim_type`: Broad claim category.
- `region`: Geographic business region.
- `previous_claims`: Historical claim count used as an analytical feature.
- `claim_status`: Example workflow state.
