# Methodology

The prototype uses rule-based, explainable indicators rather than claiming a definitive fraud prediction.

## Risk components

- Claim amount anomaly
- Historical claim frequency
- Review status
- Provider concentration
- Duplicate-pattern investigation

Each component contributes a transparent weight. Investigators can inspect the underlying factors instead of receiving only an opaque classification.

## Recommended Production Extensions

A production implementation would require validated historical labels, privacy controls, model governance, fairness testing, monitoring, and human review.
