# Implementation Notes

The architecture intentionally separates analytical processing from risk-engineering logic and presentation.

Python is used for data preparation and analytical feature generation. Java demonstrates a typed backend risk engine. SQL provides investigation-oriented queries, while the web layer presents a lightweight management dashboard.

For production, these components could be connected through a REST API and a governed relational database.
