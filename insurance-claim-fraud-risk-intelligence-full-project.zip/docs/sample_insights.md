# Sample Insights

The included synthetic dataset contains several high-value and high-frequency claim patterns.

Examples of investigation priorities include:
- CLM010: high amount and high historical claim count.
- CLM015: high amount and elevated historical frequency.
- CLM006: high amount and repeated historical claims.

These are analytical flags only and should be reviewed with underlying evidence.
