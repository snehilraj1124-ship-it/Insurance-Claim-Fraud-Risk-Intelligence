SELECT
    provider_id,
    COUNT(*) AS claim_count,
    SUM(claim_amount) AS total_claim_value,
    AVG(claim_amount) AS average_claim_value,
    SUM(CASE WHEN claim_status = 'Review' THEN 1 ELSE 0 END) AS review_count
FROM insurance_claims
GROUP BY provider_id
ORDER BY review_count DESC, total_claim_value DESC;
