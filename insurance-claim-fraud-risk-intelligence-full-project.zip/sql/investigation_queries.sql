-- High-value claims
SELECT *
FROM insurance_claims
WHERE claim_amount >= 50000
ORDER BY claim_amount DESC;

-- Customers with repeated historical claims
SELECT customer_id, COUNT(*) AS claim_count, SUM(claim_amount) AS total_claim_value
FROM insurance_claims
GROUP BY customer_id
HAVING COUNT(*) >= 2
ORDER BY total_claim_value DESC;

-- Claims currently requiring review
SELECT claim_id, customer_id, provider_id, claim_amount, claim_status
FROM insurance_claims
WHERE LOWER(claim_status) = 'review'
ORDER BY claim_amount DESC;
