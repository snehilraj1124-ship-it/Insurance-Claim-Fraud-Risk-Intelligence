CREATE TABLE insurance_claims (
    claim_id VARCHAR(20) PRIMARY KEY,
    policy_id VARCHAR(20) NOT NULL,
    customer_id VARCHAR(20) NOT NULL,
    provider_id VARCHAR(20) NOT NULL,
    claim_amount DECIMAL(14,2) NOT NULL,
    claim_date DATE NOT NULL,
    claim_type VARCHAR(50),
    region VARCHAR(50),
    previous_claims INT DEFAULT 0,
    claim_status VARCHAR(30)
);
