# SQL Layer

Use schema.sql to create the claims table, then run the investigation and provider-risk queries.
